# 连接数据库
import pymysql


def get_conn():
    conn = pymysql.connect(
        host="now.local",
        user="fan800",
        password="80807724!",
        db="sdms",
        charset="utf8",
        port=3306,
    )
    # 创建游标：
    cursor = conn.cursor()
    return conn, cursor


def close_conn(conn, cursor):
    if cursor:
        cursor.close()
    if conn:
        conn.close()


def query(sql, *args):
    '''
    :param sql:
    :param args:
    :return:返回结果，((),())形式
    '''
    conn, cursor = get_conn()
    cursor.execute(sql, args)
    res = cursor.fetchall()  # 获取结果
    close_conn(conn, cursor)
    return res


def update(sql, *args):
    conn, cursor = get_conn()
    i = cursor.execute(sql, args)
    conn.commit()
    if i >= 1:
        print("修改成功!")
    close_conn(conn, cursor)
    return i


def get_student_list():
    sql = "SELECT * FROM student"
    res = query(sql)
    return res


def get_dormitory_list():
    sql = "SELECT * FROM dormitory"
    res = query(sql)
    return res


def get_s_d_list():
    sql = "SELECT student.id, student.name, sex, d_id, dormitory.name \
            from (student left join s_d on student.id = s_d.s_id) \
            left join dormitory on dormitory.id = s_d.d_id;"
    res = query(sql)
    return res


def add_s(name, sex):
    sql = "INSERT INTO student (name, sex) VALUES ('{}', '{}');".format(name, sex)
    update(sql)


def add_d(name):
    sql = "INSERT INTO dormitory (name) VALUES ('{}');".format(name)
    update(sql)


def add_s_d(s_id, d_id):
    sql = "INSERT INTO s_d (s_id, d_id) VALUES ('{}', '{}');".format(s_id, d_id);
    update(sql)


def _del_data(t_name, id):
    sql = "DELETE FROM {} WHERE `id` = '{}'".format(t_name, id)
    update(sql)


def _del_s_d_by_s(s_id):
    sql = "DELETE FROM {} WHERE `s_id` = '{}'".format(s_id)
    update_d(sql)


def update_s(id, name, sex):
    sql = "UPDATE student set `name`='{}', sex = '{}' where `id` = '{}'".format(name, sex, id)
    update(sql)


def update_d(id, name):
    sql = "UPDATE dormitory set `name`='{}' where `id` = '{}'".format(name, id)
    update(sql)


if __name__ == '__main__':
    d = get_s_d_list()
    print(d)
