from dao import *
from dao import _del_data, _del_s_d_by_s


def print_info():
    print("-----------------欢迎使用学生宿舍管理系统-------------")
    print("学生管理命令：[list add del update] s [id 姓名 性别]")
    print("宿舍管理命令：[list add del update] d [id 地址]")
    print("学生-宿舍管理命令：[list add del] s_d [s_id d_id]")
    print("退出系统命令：exit")
    print("帮助命令：help")


def get_input():
    s = input("input:")
    s = s.strip().split(' ')
    if len(s) < 1:
        print("指令错误，请检查")
    return s


def list(s):
    if s[0] == 's':
        data = get_student_list()
        print("学生id 学生姓名 学校性别")
        for i in data:
            print(i)
    if s[0] == 'd':
        data = get_dormitory_list()
        print("宿舍id 宿舍名称")
        for i in data:
            print(i)
    if s[0] == 's_d':
        data = get_s_d_list()
        print("学生id 学生姓名 学校性别 宿舍id 宿舍名称")
        for i in data:
            print(i)


def _del(s):
    if len(s) < 2:
        print("指令错误")
        return
    if s[0] == 's':
        _del_data('student', s[1])
    elif s[0] == 'd':
        _del_data('dormitory', s[1])
    elif s[0] == 's_d':
        _del_s_d_by_s(s[1])
    else:
        print("指令错误")


def add(s):
    if len(s) < 2:
        print("指令错误")
        return
    if s[0] == 's':
        add_s(s[1], s[2])
    elif s[0] == 'd':
        add_d(s[1])
    elif s[0] == 's_d':
        add_s_d(s[1], s[2])
    else:
        print("指令错误")


def update(s):
    if len(s) < 2:
        print("指令错误")
        return
    if s[0] == 's':
        update_s(s[1], s[2], s[3])
    elif s[0] == 'd':
        update_d(s[1], s[2])
    # elif s[0] == 's_d':
    #     _del_data('s_d', s[1])
    else:
        print("指令错误")


def cmd(s):
    if s[0] == 'list':
        list(s[1:])
    elif s[0] == 'add':
        add(s[1:])
    elif s[0] == 'del':
        _del(s[1:])
    elif s[0] == 'update':
        update(s[1:])
    elif s[0] == 'exit':
        exit(0)
    elif s[0] == 'help':
        print_info()
    else:
        print("指令错误")


def index():
    print_info()
    while True:
        s = get_input()
        cmd(s)


if __name__ == '__main__':
   index()
